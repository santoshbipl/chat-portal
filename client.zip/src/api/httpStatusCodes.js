const HttpStatusCode = {
  OK: 200,
  CREATED: 201,
  UNAUTHORISED: 401,
  BAD_REQUEST: 400,
};

export default HttpStatusCode;
