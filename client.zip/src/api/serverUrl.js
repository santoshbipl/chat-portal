const ServerUrl = {
  BASE_URL: "http://127.0.0.1:7890/",
  WS_BASE_URL: "ws://127.0.0.1:7890/"
};

export default ServerUrl;
