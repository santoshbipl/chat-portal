import React, { useEffect, useState } from "react";
import ApiConnector from "../../api/apiConnector";
import ApiEndpoints from "../../api/apiEndpoints";
import AppPaths from "../../lib/appPaths";
import CookieUtil from "../../util/cookieUtil";
import ServerUrl from "../../api/serverUrl";
import Constants from "../../lib/constants";
import SocketActions from "../../lib/socketActions";
import CommonUtil from "../../util/commonUtil";
import CryptoJS from "crypto-js";
import "./chatBodyStyle.css";

let socket = new WebSocket(
	ServerUrl.WS_BASE_URL + `ws/users/${CommonUtil.getUserId()}/chat/`
);
let typingTimer = 0;
let isTypingSignalSent = false;

const SECRET_PASS = "thisisasecretpassforencryption";

const ChatBody = ({
	match,
	currentChattingMember,
	setOnlineUserList,
	currentUser,
}) => {
	const [inputMessage, setInputMessage] = useState("");
	const [messages, setMessages] = useState({});
	const [typing, setTyping] = useState(false);
	const [encryptData, setEncryptData] = useState("");

	let meStatus = "";
	if (currentChattingMember.id === currentUser) meStatus = "(me)";

	const fetchChatMessage = async () => {
		const currentChatId = CommonUtil.getActiveChatId(match);
		if (currentChatId) {
			const url =
				ApiEndpoints.CHAT_MESSAGE_URL.replace(
					Constants.CHAT_ID_PLACE_HOLDER,
					currentChatId
				) + "?limit=20&offset=0";
			const chatMessages = await ApiConnector.sendGetRequest(url);
			const resArray = chatMessages.results;

			resArray.map((message, ind) => {
				const bytes = CryptoJS.AES.decrypt(message.message, SECRET_PASS);
				const msg = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
				chatMessages.results[ind].message = msg;
				console.log(chatMessages.results[ind].message)
			});

			setMessages(chatMessages);
		}
	};

	useEffect(() => {
		fetchChatMessage();
	}, [CommonUtil.getActiveChatId(match)]);

	const loggedInUserId = CommonUtil.getUserId();
	const getChatMessageClassName = (userId) => {
		return loggedInUserId === userId
			? "chat-message-right pb-3"
			: "chat-message-left pb-3";
	};

	socket.onmessage = (event) => {
		const data = JSON.parse(event.data);
		if (data.message === "roomid:qwerty") {
			window.location.href = "/room/qwerty";
			return;
		}

		const chatId = CommonUtil.getActiveChatId(match);
		const userId = CommonUtil.getUserId();
		if (chatId === data.roomId) {
			if (data.action === SocketActions.MESSAGE) {
				data["userImage"] =
					ServerUrl.BASE_URL.slice(0, -1) + data.userImage;
				const bytes = CryptoJS.AES.decrypt(data.message, SECRET_PASS);
				const msg = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
				data.message = msg;
				setMessages((prevState) => {
					let messagesState = JSON.parse(JSON.stringify(prevState));
					messagesState.results.unshift(data);
					return messagesState;
				});
				setTyping(false);
			} else if (
				data.action === SocketActions.TYPING &&
				data.user !== userId
			) {
				setTyping(data.typing);
			}
		}
		if (data.action === SocketActions.ONLINE_USER) {
			setOnlineUserList(data.userList);
		}
	};

	const messageSubmitHandler = (event) => {
		event.preventDefault();
		if (inputMessage) {
			socket.send(
				JSON.stringify({
					action: SocketActions.MESSAGE,
					message: encryptData,
					user: CommonUtil.getUserId(),
					roomId: CommonUtil.getActiveChatId(match),
				})
			);
		}
		setInputMessage("");
		setEncryptData("");
	};

	const sendTypingSignal = (typing) => {
		socket.send(
			JSON.stringify({
				action: SocketActions.TYPING,
				typing: typing,
				user: CommonUtil.getUserId(),
				roomId: CommonUtil.getActiveChatId(match),
			})
		);
	};

	const chatMessageTypingHandler = (event) => {
		if (event.keyCode !== Constants.ENTER_KEY_CODE) {
			if (!isTypingSignalSent) {
				sendTypingSignal(true);
				isTypingSignalSent = true;
			}
			clearTimeout(typingTimer);
			typingTimer = setTimeout(() => {
				sendTypingSignal(false);
				isTypingSignalSent = false;
			}, 3000);
		} else {
			clearTimeout(typingTimer);
			isTypingSignalSent = false;
		}
	};

	const callClickHandler = () => {
		socket.send(
			JSON.stringify({
				action: SocketActions.MESSAGE,
				message: "roomid:qwerty",
				user: CommonUtil.getUserId(),
				roomId: CommonUtil.getActiveChatId(match),
			})
		);
	};

	return (
		<div className="col-12 col-sm-8 col-md-8 col-lg-8 col-xl-10 pl-0 pr-0">
			<div className="py-2 px-4 border-bottom d-none d-lg-block">
				<div className="d-flex align-items-center py-1">
					<div className="position-relative">
						<img
							src={currentChattingMember?.image}
							className="rounded-circle mr-1"
							alt="User"
							width="40"
							height="40"
						/>
					</div>
					<div className="flex-grow-1 pl-3">
						<strong>
							{currentChattingMember?.name}
							{meStatus}
						</strong>
					</div>
					{meStatus === "" && (
						<button
							onClick={callClickHandler}
							className="btn btn-outline-warning btn-block mt-1"
							style={{ width: "5rem" }}
						>
							<svg
								xmlns="http://www.w3.org/2000/svg"
								width="16"
								height="16"
								fill="currentColor"
								class="bi bi-telephone-fill"
								viewBox="0 0 16 16"
							>
								<path
									fill-rule="evenodd"
									d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877z"
								/>
							</svg>
						</button>
					)}
				</div>
			</div>
			<div className="position-relative">
				<div
					id="chat-message-container"
					className="chat-messages pl-4 pt-4 pr-4 pb-1 d-flex flex-column-reverse"
				>
					{typing && (
						<div className="chat-message-left chat-bubble mb-1">
							<div className="typing">
								<div className="dot"></div>
								<div className="dot"></div>
								<div className="dot"></div>
							</div>
						</div>
					)}
					{messages?.results?.map((message, index) => (
						<div
							key={index}
							className={getChatMessageClassName(message.user)}
						>
							<div>
								<img
									src={message.userImage}
									className="rounded-circle mr-1"
									alt={message.userName}
									width="40"
									height="40"
								/>
								<div className="text-muted small text-nowrap mt-2">
									{CommonUtil.getTimeFromDate(
										message.timestamp
									)}
								</div>
							</div>
							<div className="flex-shrink-1 bg-light ml-1 rounded py-2 px-3 mr-3">
								<div className="font-weight-bold mb-1">
									{message.userName}
								</div>
								{message.message}
							</div>
						</div>
					))}
				</div>
			</div>
			<div className="flex-grow-0 py-3 px-4 border-top">
				<form onSubmit={messageSubmitHandler}>
					<div className="input-group">
						<input
							onChange={(event) => {
								const encData = CryptoJS.AES.encrypt(
									JSON.stringify(event.target.value),
									SECRET_PASS
								).toString();
								setEncryptData(encData);
								return setInputMessage(event.target.value);
							}}
							onKeyUp={chatMessageTypingHandler}
							value={inputMessage}
							id="chat-message-input"
							type="text"
							className="form-control"
							placeholder="Type your message"
							autoComplete="off"
						/>
						<button
							id="chat-message-submit"
							className="btn btn-outline-warning"
						>
							Send
						</button>
					</div>
				</form>
			</div>
		</div>
	);
};

export default ChatBody;
